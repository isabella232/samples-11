/**************************************************************************
 * 
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2010 Adobe Systems Incorporated
 * All Rights Reserved.
 * 
 * NOTICE:  Adobe permits you to use, modify, and distribute this file in 
 * accordance with the terms of the Adobe license agreement accompanying it.  
 * If you have received this file from a source other than Adobe, 
 * then your use, modification, or distribution of it requires the prior 
 * written permission of Adobe.
 **************************************************************************/
package com.adobe.livecycle.authentication.ic;

import com.adobe.idp.dsc.DSCRuntimeException;
import com.adobe.idp.dsc.clientsdk.ServiceClientFactory;
import com.adobe.idp.dsc.component.ComponentContext;
import com.adobe.idp.dsc.component.LifeCycle;
import com.adobe.idp.dsc.registry.ServiceNotFoundException;
import com.adobe.idp.dsc.registry.infomodel.ServiceConfiguration;
import com.adobe.idp.dsc.registry.service.CreateServiceConfigurationInfo;
import com.adobe.idp.dsc.registry.service.NoActiveServiceConfigurationException;
import com.adobe.idp.dsc.registry.service.client.ServiceRegistryClient;
import com.adobe.idp.dsc.util.DOMUtil;
import com.adobe.logging.AdobeLogger;

public class LifeCycleImpl implements LifeCycle {

	private static final AdobeLogger LOGGER = AdobeLogger
			.getAdobeLogger(LifeCycleImpl.class);

	private static final String SERVICE_NAME = "SampleAssignmentProvider";
	
	private transient ComponentContext mCtx;

	public void setComponentContext(final ComponentContext context) {
		LOGGER.info("setComponentContext: "
				+ context.getComponent().getComponentId());
		mCtx = context;
	}

	public void startService(final String service) {
		ServiceClientFactory mServiceFactory = null;
		LOGGER.info("Called onStart: " + mCtx.getComponent().getComponentId()
				+ " for " + service);

		try {
			LOGGER.info("Starting Service :  " + service);
			mServiceFactory = ServiceClientFactory.createInstance();
			final ServiceRegistryClient srClient = new ServiceRegistryClient(
					mServiceFactory);

			ServiceConfiguration config = null;
			try {
				config = srClient.getHeadActiveConfiguration(service);
			} catch (ServiceNotFoundException ex) {
				LOGGER.warning("Service not found");
			} catch (NoActiveServiceConfigurationException ex) {
				LOGGER.warning("No active service configuration");
			}

			if (config == null) {
				LOGGER.info("Calling deploy for Service Name: " + service);
				final CreateServiceConfigurationInfo cscInfo = new CreateServiceConfigurationInfo();
				cscInfo.setComponentId(mCtx.getComponent().getComponentId());
				cscInfo.setComponentVersion(mCtx.getComponent().getVersion());
				cscInfo.setServiceId(service);
				cscInfo.setMajorVersion(1);
				cscInfo.setDescriptor(DOMUtil.toString(mCtx.getComponent()
						.getServiceDescriptor(service)));
				cscInfo.setStartWithComponent(true);
				srClient.createAndDeploy(cscInfo, null);
			}

			LOGGER.info("Successfully Started Service :  " + service);
		} catch (Exception ex) {
			throw new DSCRuntimeException(ex);
		}
	}

	public void onStart() {
		LOGGER.info("Called onStart::: " + mCtx.getComponent().getComponentId());
		startService(SERVICE_NAME);
	}

	public void onStop() {
		LOGGER.info("Called onStop::: " + mCtx.getComponent().getComponentId());
	}

}
