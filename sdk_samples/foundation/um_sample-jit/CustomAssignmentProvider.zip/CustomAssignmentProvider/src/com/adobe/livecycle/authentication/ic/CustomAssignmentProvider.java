/**************************************************************************
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2010 Adobe Systems Incorporated
 * All Rights Reserved.
 * NOTICE:  Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying it.
 * If you have received this file from a source other than Adobe,
 * then your use, modification, or distribution of it requires the prior
 * written permission of Adobe.
 **************************************************************************/
package com.adobe.livecycle.authentication.ic;

import com.adobe.idp.um.api.AuthorizationManager;
import com.adobe.idp.um.api.UMConstants;
import com.adobe.idp.um.api.UMException;
import com.adobe.idp.um.api.UMFactory;
import com.adobe.idp.um.api.UMLocalUtils;
import com.adobe.idp.um.api.infomodel.User;
import com.adobe.idp.um.spi.authentication.AssignmentProvider;
import com.adobe.logging.AdobeLogger;

public class CustomAssignmentProvider implements AssignmentProvider {

	private static final String CUSTOM_AP = "CustomAssignmentProvider";

	private static final AdobeLogger LOGGER = AdobeLogger
			.getAdobeLogger(CustomAssignmentProvider.class);

	/**
	 * Implement the method that provided by UM, and tries to assign roles or
	 * permissions or group memberships to user created via Just in time
	 * provisioning.
	 * 
	 * @param user
	 *            the User created via Just in time provisioning process.
	 * @return a boolean flag saying assignment was successful or not.
	 */
	public Boolean assign(final User user) {
		final UMFactory umFactory = UMFactory.getInstance();
		Boolean result = false;

		try {
			final AuthorizationManager auManager = umFactory
					.getAuthorizationManager(UMLocalUtils.getSystemContext());
			auManager.assignRole(
					UMConstants.BasicRoles.BASIC_ROLE_ADMIN_CONSOLE,
					new String[] { user.getOid() });
			result = true;
			LOGGER.info("The user has been assigned Administrator Console user role successfully!");
		} catch (UMException e) {
			LOGGER.warning("Failed to assign role to user when running Just In Time");
		}

		return result;
	}

	/**
	 * Implement the method that provided by UM, and it returns the name of the
	 * Assignment Provider by which it will be registered in preferences.
	 * 
	 * @return the name of this Assignment Provider by which it is recognized in
	 *         Configuration.
	 */
	public String getName() {
		return CUSTOM_AP;
	}

}
