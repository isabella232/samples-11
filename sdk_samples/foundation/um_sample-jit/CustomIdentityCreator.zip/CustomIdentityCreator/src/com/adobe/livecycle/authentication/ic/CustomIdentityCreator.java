/**************************************************************************
 *
 * ADOBE SYSTEMS INCORPORATED
 * Copyright 2010 Adobe Systems Incorporated
 * All Rights Reserved.
 *
 * NOTICE:  Adobe permits you to use, modify, and distribute this file in
 * accordance with the terms of the Adobe license agreement accompanying it.
 * If you have received this file from a source other than Adobe,
 * then your use, modification, or distribution of it requires the prior
 * written permission of Adobe.
 **************************************************************************/

package com.adobe.livecycle.authentication.ic;

import com.adobe.idp.um.api.DirectoryManager;
import com.adobe.idp.um.api.UMAuthenticationUtil;
import com.adobe.idp.um.api.UMException;
import com.adobe.idp.um.api.UMFactory;
import com.adobe.idp.um.api.UMLocalUtils;
import com.adobe.idp.um.api.infomodel.Principal;
import com.adobe.idp.um.api.infomodel.impl.UserImpl;
import com.adobe.idp.um.spi.authentication.AuthResponse;
import com.adobe.idp.um.spi.authentication.AuthResponseImpl;
import com.adobe.idp.um.spi.authentication.IdentityCreator;
import com.adobe.idp.um.spi.authentication.UserProvisioningBO;
import com.adobe.logging.AdobeLogger;

public class CustomIdentityCreator implements IdentityCreator {

	private static final AdobeLogger LOGGER = AdobeLogger
			.getAdobeLogger(CustomIdentityCreator.class);

	private static final String CUSTOM_IC = "CustomIdentityCreator";

	private static final String PASSWORD = "password";

	/**
	 * Implement the method that provided by UM, and tries to create a user with
	 * the info provided in the <code>UserProvisioningBO</code> object.
	 * 
	 * @param provisionBO
	 *            an object of
	 *            <code>com.adobe.idp.um.spi.authenticationUserProvisioningBO</code>
	 * @return an object of
	 *         <code>com.adobe.idp.um.spi.authentication.AuthResponse</code>
	 */
	public AuthResponse create(final UserProvisioningBO provisionBO) {
		final UMFactory umFactory = UMFactory.getInstance();
		Principal principal = null;
		AuthResponse authResponse = null;
		final UserImpl user = new UserImpl();

		user.setCanonicalName(provisionBO.getUserIdentifier());
		user.setUserid(provisionBO.getUserIdentifier());
		user.setGivenName(provisionBO.getUserIdentifier());
		user.setFamilyName(provisionBO.getUserIdentifier());
		user.setDomainName(provisionBO.getDomain());
		user.setPrincipalType(Principal.PRINCIPALTYPE_USER);
		user.setIsSystem(false);
		
		// If create an Enterprise User, switch to false.
		user.setLocal(true);

		try {
			final DirectoryManager directoryManager = umFactory
					.getDirectoryManager(UMLocalUtils.getSystemContext());

			// Known issue, the PASSWORD is a dummy password to fulfill API signature.
			// If create an Enterprise User, use directorManager.createDirectoryPrincipal(user).
			final String oid = directoryManager.createLocalUser(user, PASSWORD);
			
			principal = directoryManager.findPrincipal(oid);
		} catch (UMException e) {
			LOGGER.warning("Failed to create local user when running Just In Time");
		}

		if (principal != null) {
			authResponse = new AuthResponseImpl();
			authResponse.setUsername(user.getUserid());
			authResponse.setDomain(provisionBO.getDomain());
			authResponse.setAuthType(provisionBO.getAuthScheme());
			authResponse.setAuthStatus(AuthResponse.AUTH_SUCCESS);
			provisionBO.getCredentials().put(
					UMAuthenticationUtil.authenticatedUserKey, principal);
			LOGGER.info("Create user successfully!");
		}
		
		return authResponse;
	}

	/**
	 * Implement the method that provided by UM, and it returns the name of the
	 * Identity Creator by which it will be registered in preferences.
	 * 
	 * @return the name of this Identity Creator by which it is recognized in
	 *         Configuration.
	 */
	public String getName() {
		return CUSTOM_IC;
	}

}
